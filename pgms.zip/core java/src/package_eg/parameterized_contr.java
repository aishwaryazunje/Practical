package package_eg;

public class parameterized_contr {
	int age;
	String name;
	parameterized_contr(int a, String n)
	{
		age=a;
		name=n;
	}
	
	void show()
	{
	System.out.println(age+ " "+name);}
	public static void main(String args[])
	{
		parameterized_contr d= new parameterized_contr( 30, "Aishwarya");
		parameterized_contr d1= new parameterized_contr( 35, "Priya");
		parameterized_contr d2= new parameterized_contr( 40, "Nisha");
	}
	


	
}
