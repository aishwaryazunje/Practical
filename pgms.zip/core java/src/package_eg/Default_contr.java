package package_eg;

public class Default_contr {
	Default_contr()
	{
		System.out.println("Default contr called");
		}
	
public static void main(String args[])
{
	Default_contr obj = new Default_contr();
}
}
