package package_eg;

public class Default_contr2 {
	int s1_no=1;
	String Name= " Aishwarya";
	void result()
	{
		System.out.println(s1_no+" "+Name);
	}
	public static void main(String args[])
	{
		Default_contr2 obj = new Default_contr2();
		System.out.println(obj.s1_no+" "+obj.Name);
		
	}

}
