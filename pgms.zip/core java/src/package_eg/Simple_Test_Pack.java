package package_eg;

public class Simple_Test_Pack 
{
	public static void main(String args[])
	{
	System.out.println(" Creating 1st Package");

}
}