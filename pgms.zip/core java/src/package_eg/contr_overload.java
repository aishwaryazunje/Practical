package package_eg;

public class contr_overload {
	int age;
	String name;
	String address;
	//contructor 1 with 2 agrgument
	contr_overload(int a, String n)
	{
  age=a;
  name=n;
	}
	//contructor 2 with 3 argument
	contr_overload(int a, String n , String add)
	{
		age=a;
		name=n;
		address=add;
		}
	 public void show()
	 {
		 System.out.println("Name="+name+" Age="+age+" Address="+address);
	}
	 public static void main(String args[])
	
	 {
		 contr_overload ob= new contr_overload(24,"Aishwarya");
		 contr_overload ob2= new contr_overload(20,"Riya", "solapur");
		 ob.show();
		 ob2.show();
		 
	 }
}
