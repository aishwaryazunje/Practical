package package_eg;

public class Default_AM_Tst {
	void show()
	{
		System.out.println("Default Method");
	}

}
