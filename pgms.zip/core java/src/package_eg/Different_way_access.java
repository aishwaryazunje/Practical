package package_eg;
import com.mypackage;

public class Different_way_access {
	public static void main(string args[])

}
