package package_eg;

public class protected_Test {
	protected void show()
	{
		System.out.println("protected Method");
	}

}
